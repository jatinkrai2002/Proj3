# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID

import Pyro5.api
from Lib.clsProject3LeaveOperations import clsProject3LeaveOperations
from Lib.URLHelper import URLHelper
import os
import logging
import threading


# Setup logging
log_dir = 'logs'

if not os.path.exists(log_dir):
    os.makedirs(log_dir)


logging.basicConfig(filename=os.path.join(log_dir, 'clsLeaveserver.log'), level=logging.INFO)

logger = logging.getLogger("clsLeaveServer")

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def start_Project3server():

    #Server is always authenticated.
    ReturnAccessVal = True

    if (ReturnAccessVal == False):
        print ("Access denied for client")
    else:
        print ("Access successful")
        #Act as Server.
        try:
            #make it server ready for remote process.
            daemon = Pyro5.api.Daemon()
        except Exception as error:
            print("rPyro5.api.Daemo(): failed.")
            print(error)
        finally:
            print("Pyro5.api.Daemo(): completed successfully.")

        try:
            #make it server ready for remote process.
            uri = daemon.register(clsProject3LeaveOperations)
        except Exception as error:
            print("Pyro5.api.Daemo.register(): failed.")
            print(error)
        finally:
            print("Pyro5.api.Daemo.register() : completed successfully.")
        

        try:
            currentworkingdir = os.getcwd()
            """
                data_folder = Path("source_data/text_files/")
                file_to_open = data_folder / "raw_data.txt"
                print(file_to_open.read_text())
            """

            URLPath = currentworkingdir + "\\ServerOutput\\UrlfileforTimeServer.txt"
            URLFileObj = URLHelper(URLPath)
            URLFileObj.writeServerURLFile(str(uri))


            #make it server ready for remote process.
            print("UnicastRemoteObject for Project 3 Leave Server=")
            print("Ready. UnicastRemoteObject URI=", uri)
            daemon.requestLoop()
        except Exception as error:
            print("Pyro5.api.Daemo.requestLoop(): failed.")
            print(error)
        finally:
            print("Pyro5.api.Daemo.requestLoop() : completed successfully.")

if __name__ == "__main__":
    server_thread = threading.Thread(target=start_Project3server)
    server_thread.start()
