#client
# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID

from Lib.URLHelper import URLHelper
from Lib.clsProject3LeaveData import clsProject3LeaveData
from Lib.clsProject3ConnectionPersistence import clsProject3ConnectionPersistence
# from Lib.clsProject3Authentication import clsProject3Authentication
import Pyro5.api
from pathlib import Path
import os
import logging
import threading
import getpass


# Setup logging
log_dir = 'logs'

if not os.path.exists(log_dir):
    os.makedirs(log_dir)


logging.basicConfig(filename=os.path.join(log_dir, 'clsLeaveclient.log'), level=logging.INFO)

logger = logging.getLogger("clsLeaveclient")


# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def client_thread(remote_server):

    try:
        MyProcessName = "P2"
        empid = "emp2"
        remote_server._pyroClaimOwnership()
        #this is helper class
        clientHelp = URLHelper("URLPath")
        clientPersistance = clsProject3ConnectionPersistence()
        # UserLeaves = clsProject3LeaveData()
       # userauth = clsProject3Authentication()

        # user authentication.
        print(f"This is your Process# P2 and userid : project3user and password : project3 to connect to the project 3 Leave server")
        username = input("Enter username: ")
        password = getpass.getpass("Enter password: ")
        # Simple authentication logic (replace with actual authentication)
        AccessValue = remote_server.authenticateuser(username, password,  MyProcessName)

        if (AccessValue == True) and (MyProcessName == "P2"):
            print(f" You are successfully authenticated and your empid is ({empid})")
            while True:
                command = input("Enter command (get <empid> balance /apply <empid> <leave>/  update <empid> leavebalance> /delete <empid> <numofleave>/ help / exit): ")
                if command.startswith("get "):
                    if (empid in command):
                        response = remote_server.getLeaveBalance(command, MyProcessName)
                        print (f" You are successfully completed and status : {response}")
                    else:
                        print (f"Command error: Please use your empid as {empid} ")
                elif command.startswith("apply "):
                    if (empid in command):
                        response = remote_server.ApplyLeave(command, MyProcessName)
                        print (f" You are successfully completed and status : {response}")
                    else:
                        print (f"Command error: Please use your empid as {empid} ")

                elif command.startswith("update "):
                    if (empid in command):
                        response = remote_server.UpdateLeave(command, MyProcessName)
                        print (f" You are successfully completed and status : {response}")
                    else:
                        print (f"Command error: Please use your empid as {empid} ")
                    
                elif command.startswith("delete"): 
                   if (empid in command):
                        response = remote_server.DeleteLeave(command, MyProcessName)
                        print (f" You are successfully completed and status : {response}") 
                   else:
                        print (f"Command error: Please use your empid as {empid} ") 
                        
                elif command == "help":
                    clientHelp.show_help(command, MyProcessName)
                elif command == "exit":
                    clientPersistance.IsConnectionExist(command, MyProcessName)
                    break
                else:
                    logging.warning("Invalid command. Type 'help' for a list of commands.")
        else:
            print(f"Sorry, you have entered either userid or password incorrect and reconnect using re run clinet") 
    except Exception as error:
        print(f"client_thread:  error : {error}")


def start_Proejct3Client():
    try:
        MyProcessName = "P2"
        currentworkingdir = os.getcwd()
        """
            data_folder = Path("source_data/text_files/")
            file_to_open = data_folder / "raw_data.txt"
            print(file_to_open.read_text())
        """
        #read url from file
        URLPath = currentworkingdir + "\\ServerOutput\\UrlfileforTimeServer.txt"
        URLFileObj = URLHelper(URLPath)
        uri = URLFileObj.readserverURLFile()

        if ((uri is None) or (len(uri) < 1)):
            uri = input("Enter the UnicastRemoteObject for Project 3 LeaveServer URI: ")

        print (f"URI of the Project 3 LeaveServer URI is : {uri}")    

        print (f" Project 3 Leaveserver connected from Client Process : {MyProcessName}") 

        remote_server = Pyro5.api.Proxy(uri)

        client_thread_instance = threading.Thread(target=client_thread, args=(remote_server,))
        client_thread_instance.start()

        print (f" Project 3 Leaveserver completed  from Client Process : {MyProcessName}") 

        # remote_process = clsProject3FileOperations(uri,  MyProcessName)
        
    except Exception as error:
            print("Pyro5.api.Proxy(): Project 3 LeaveServer Pyro5.api.Proxy failed while calling.")
            print (error)
    finally:
            print("Pyro5.api.Proxy(): Project 3 LeaveServer Pyro5.api.Proxy completed successfully while calling.")


if __name__ == "__main__":
    start_Proejct3Client()
