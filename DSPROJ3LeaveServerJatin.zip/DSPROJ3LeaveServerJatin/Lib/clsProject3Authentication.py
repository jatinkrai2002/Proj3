
# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID
"""
Client Authentication: 
        The client must authenticate by entering a server-defined password (default admin and password password.)
"""

import logging
import random


class clsProject3Authentication():
    # assign static
    ServerOTP = ""

    #Constuctor
    def __init__(self):
        self.ServerOTP = ""
        self.password = "Hello"

    #password based.
    def authenticateClient(self, password):
        print(f"clsProject3Authentication(): authenticateClient() : function started.")
        if password == self.password:
            logging.info("Client authenticated successfully.")
            print(f"clsProject3Authentication(): authenticateClient() : function completed.")
            return "Hello"
        else:
            logging.warning("Client authentication failed.")
            print(f"clsProject3Authentication(): authenticateClient() : function completed.")
            return "Authentication Failed"

    #password based
    def authenticateServer(self):
        print(f"clsProject3Authentication(): authenticateServer() : function started.")
        
        #simple Hello world password
        # self.password = input("Enter password: ")                
        response = self.password
        if response == "Hello":
            logging.info("Authenticated successfully.")
            print(f"clsProject3Authentication(): authenticateServer() : function completed.")
            return True
        else:
            logging.warning("Authentication failed.")
            print(f"clsProject3Authentication(): authenticateServer() : function completed.")
            return False
        
    #userid and password,

    def authenticateuser(self, userid, password):
        print(f"clsProject3Authentication(): authenticateuser() : function started.")
        username = userid.lower()
        password = password.lower()    #getpass.getpass("Enter password: ")
        # Simple authentication logic (replace with actual authentication)
        if username == "project3user" and password == "project3":
            print(f"clsProject3Authentication(): authenticateuser() : function finished.")
            return True
        else:
            #logger.error("Authentication failed")
            print(f"clsProject3Authentication(): authenticateuser() : function finished.")
            return False
   
    #OTP based
    def getOTP(self):
        print(f"clsProject3Authentication():: getOTP() : function started.")
        try:
            otp = ""
            for num in range(6):
                otp += str(random.randint(0,9))
            self.ServerOTP = otp
            print(f"clsProject3Authentication():: getOTP() : function completed with {self.ServerOTP}.")
            return self.ServerOTP
        except Exception as error:
            logging.warning(f"OTP generation error : {error}")
    