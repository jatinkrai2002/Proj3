
# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID

"""
 Connection Persistence:
 The connection should remain active until the client explicitly decides to terminate it.

"""

# Create a
class clsProject3ConnectionPersistence():
    #Constuctor
    def __init__(self):
        self.MyCurrentProcessName = "P"
        
    def IsConnectionExist(self, command, myprocessname):
       
        self.MyCurrentProcessName = myprocessname
        print(f"clsProject3ConnectionPersistence(): IsConnectionExist() : for Process : {self.MyCurrentProcessName} function started with command = {command}.")
        
        if (command.lower() == "exit"):
            print(f"clsProject3ConnectionPersistence(): IsConnectionExist() : for Process : {self.MyCurrentProcessName} function completed with command = {command}.")
