# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID


class URLHelper:

    URIValue = ""

    def __init__(self, currentRLFolderFileName) -> None:
        self.URIValue = ""
        self.ServerURLPath = currentRLFolderFileName
        self.MyCurrentProcessName = "P"
   
    def show_help(self, command, myprocessname):
        self.MyCurrentProcessName = myprocessname

        print(f"URLHelper(): show_help() : for Process : {self.MyCurrentProcessName} function started with command = {command}.")
        print("""
        Available commands:
        apply <empid> <leave> - Apply leave and adjust the leave balance once approved otherwise denied with no update.
        get <empid> balance  - show the leave balance of empid.
        update <empid> <leavebalance>  - update the leave blance of empid.
        delete <empid> <numofleave>   - subtrace numofleave of empid available balance leave.
        exit            - Exit the application
        """)
        print(f"URLHelper(): show_helpad_file() : for Process : {self.MyCurrentProcessName} function completed with command = {command}.")

    def readserverURLFile(self):
        try:
            # Open function to open the file
            # (same directory) in append mode and
            URLfile1 = open(self.ServerURLPath,"r+")
           

            for line in URLfile1:
                # Print each line
                self.URIValue = line.strip()
                print(self.URIValue)

            #self.URIValue = URLfile1.readline(1)
            print(f"Server URI Value is : {self.URIValue}")
            URLfile1.close()
            return self.URIValue
        except Exception as error:
            print(f"Error occured in the URLHelper. readserverURLFie() with error : {error}")

    def writeServerURLFile(self, URLValue):
        try:
            # store its reference in the variable file1
            # and "MyFile2.txt" in D:\Text in file2
            self.URIValue = URLValue
            URLfile2 = open(self.ServerURLPath,"w+")
            URLfile2.writelines(URLValue) 
            URLfile2.close() 
            print(f"Server URI Value is : {self.URIValue} into the File : {self.ServerURLPath} ") 
        except Exception as error:
            print(f"Error occured in the URLHelper. WriteserverURLFie() with error : {error}")