# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID

"""
    The server maintains a record of each employee's leave details, which includes:

    Total entitled leaves: The total number of leaves the employee can take.

    Current leave balance: The number of leaves the employee has remaining.

    The server listens for requests from multiple clients, processes leave requests, and sends back appropriate responses.
"""
import Pyro5.api
import logging
from Lib.clsProject3Authentication import clsProject3Authentication
from Lib.clsProject3LeaveData import clsProject3LeaveData
#from clsProject3Authentication import clsProject3Authentication
#from clsProject3LeaveData import clsProject3LeaveData

@Pyro5.api.expose
class clsProject3LeaveOperations():

    # assign
    def __init__(self):
        self.LeaveBank  = clsProject3LeaveData()
        self.Authentication = clsProject3Authentication()
        self.MyCurrentProcessName = "P"

  
    @Pyro5.api.expose
    def getLeaveBalance(self, command, MyProcessName): 
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject3LeaveOperations(): getLeaveBalance() : for Process : {self.MyCurrentProcessName} function started with command = {command}")

        strleavedeatils = command.split(' ')

        if(len(strleavedeatils) > 0):
            empid =  strleavedeatils[1]
            leaveblance = strleavedeatils[2]
        else:
            strleavedeatils = input("Enter leave command: ")
        try:
            #leave databank
            leavedata = self.LeaveBank.getLeaveData()
            if leavedata:
                if empid not in leavedata:
                    return "Employee ID not found"
                
                if (leaveblance.lower() == "balance"):
                    employeeleaves = leavedata[empid]
                    Availableleavedays = employeeleaves["balance"]
                    print(f"clsProject3LeaveOperations(): getLeaveBalance() : for Process : {self.MyCurrentProcessName} function completed.")
                    return str(Availableleavedays)
                else:
                    Availableleavedays = 0
                    print(f"clsProject3LeaveOperations(): getLeaveBalance() : for Process : {self.MyCurrentProcessName} function completed.")
                    return str(Availableleavedays)

            else:
                Availableleavedays = 0
                print(f"clsProject3LeaveOperations(): getLeaveBalance() : for Process : {self.MyCurrentProcessName} function completed.")
                return str(Availableleavedays)
        except Exception as e:
            logging.error(f"Error in getLeaveBalance: {e}")


    @Pyro5.api.expose
    def ApplyLeave(self, command, MyProcessName): 
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject3LeaveOperations(): ApplyLeave() : for Process : {self.MyCurrentProcessName} function started with command = {command}")

        strleavedeatils = command.split(' ')

        if(len(strleavedeatils) > 0):
            empid =  strleavedeatils[1]
            numofleave = strleavedeatils[2]
        else:
            strleavedeatils = input("Enter leave command: ")
        try:
            #leave databank
            leavedata = self.LeaveBank.getLeaveData()
            if leavedata:
                if empid not in leavedata:
                    return "Employee ID not found"
                
                numofleave = int(numofleave)
                if numofleave <= 0:
                    return "Invalid number of leave days"
                
                employeeleaves = leavedata[empid]
                Availableleavedays = employeeleaves["balance"]

                if numofleave <= Availableleavedays:
                    employeeleaves["balance"] -= numofleave
                    leavebalancedata = employeeleaves["balance"]
                    print(f"Leave approved for {empid}. Remaining balance: {leavebalancedata}")
                    print (f" clsProject3LeaveOperations(): ApplyLeave() : for Process : {self.MyCurrentProcessName}  for employee id : {empid} request Leave method - finished ")
                    return "Approved"
                else:
                    print(f"Leave denied for {empid}. Insufficient balance.")
                    print (f"clsProject3LeaveOperations(): ApplyLeave() : for Process : {self.MyCurrentProcessName} for employee id : {empid} request Leave method - finished ")
                    return "Denied"
            else:
                Availableleavedays = 0
                print(f"clsProject3LeaveOperations(): ApplyLeave() : for Process : {self.MyCurrentProcessName} function completed.")
                return str(Availableleavedays)
        except Exception as e:
            logging.error(f"Error in ApplyLeave: {e}")
    

    @Pyro5.api.expose
    def UpdateLeave(self, command, MyProcessName): 
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject3LeaveOperations(): UpdateLeave() : for Process : {self.MyCurrentProcessName} function started with command = {command}")

        strleavedeatils = command.split(' ')

        if(len(strleavedeatils) > 0):
            empid =  strleavedeatils[1]
            numofleave = strleavedeatils[2]
        else:
            strleavedeatils = input("Enter leave command: ")
        try:
            #leave databank
            leavedata = self.LeaveBank.getLeaveData()
            if leavedata:
                if empid not in leavedata:
                    return "Employee ID not found"
                
                numofleave = int(numofleave)
                if numofleave <= 0:
                    return "Invalid number of leave days"
                
                employeeleaves = leavedata[empid]
                Availableleavedays = employeeleaves["balance"]

                if numofleave >= 0:
                    employeeleaves["balance"] = numofleave
                    leavebalancedata = employeeleaves["balance"]
                    print(f"Leave updated for {empid}. Remaining balance: {leavebalancedata}")
                    print (f" clsProject3LeaveOperations(): UpdateLeave() : for Process : {self.MyCurrentProcessName}  for employee id : {empid} request Leave method - finished ")
                    return "Approved"
                else:
                    print(f"Leave denied for {empid}. Insufficient balance.")
                    print (f"clsProject3LeaveOperations(): UpdateLeave() : for Process : {self.MyCurrentProcessName} for employee id : {empid} request Leave method - finished ")
                    return "Denied"
            else:
                Availableleavedays = 0
                print(f"clsProject3LeaveOperations(): UpdateLeave() : for Process : {self.MyCurrentProcessName} function completed.")
                return str(Availableleavedays)
        except Exception as e:
            logging.error(f"Error in UpdateLeave: {e}")
    
    @Pyro5.api.expose
    def DeleteLeave(self, command, MyProcessName): 
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject3LeaveOperations(): DeleteLeave() : for Process : {self.MyCurrentProcessName} function started with command = {command}")

        strleavedeatils = command.split(' ')

        if(len(strleavedeatils) > 0):
            empid =  strleavedeatils[1]
            numofleave = strleavedeatils[2]
        else:
            strleavedeatils = input("Enter leave command: ")
        try:
            #leave databank
            leavedata = self.LeaveBank.getLeaveData()
            if leavedata:
                if empid not in leavedata:
                    return "Employee ID not found"
                
                numofleave = int(numofleave)
                if numofleave <= 0:
                    return "Invalid number of leave days"
                
                employeeleaves = leavedata[empid]
                Availableleavedays = employeeleaves["balance"]

                if numofleave <= Availableleavedays:
                    employeeleaves["balance"] -= numofleave
                    leavebalancedata = employeeleaves["balance"]
                    print(f"Leave deleted for {empid}. Remaining balance: {leavebalancedata}")
                    print (f" clsProject3LeaveOperations(): DeleteLeave() : for Process : {self.MyCurrentProcessName}  for employee id : {empid} request Leave method - finished ")
                    return "Approved"
                else:
                    print(f"Leave denied for {empid}. Insufficient balance.")
                    print (f"clsProject3LeaveOperations(): DeleteLeave() : for Process : {self.MyCurrentProcessName} for employee id : {empid} request Leave method - finished ")
                    return "Denied"
            else:
                Availableleavedays = 0
                print(f"clsProject3LeaveOperations(): DeleteLeave() : for Process : {self.MyCurrentProcessName} function completed.")
                return str(Availableleavedays)
            
        except Exception as e:
            logging.error(f"Error in DeleteLeave: {e}")
    

    @Pyro5.api.expose
    def authenticateuser(self, username, password, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject3LeaveOperations(): authenticateuser() : for Process : {self.MyCurrentProcessName} function started.")
        try:
            #Authentication service provide OTP to the client.
            self.userstatus = self.Authentication.authenticateuser(username, password)
            print(f"clsProject3LeaveOperations(): authenticateuser() : for Process : {self.MyCurrentProcessName} function completed with {self.userstatus}.")
            return self.userstatus
        except Exception as error:
            logging.warning(f"authenticateuser generation error : {error}")

"""

    command = "apply emp2 2"
    MyProcessName = "P1"
    remote_server = clsProject3LeaveOperations()
    response = remote_server.ApplyLeave(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")



    command = "get emp2 balance"
    MyProcessName = "P1"


    response = remote_server.getLeaveBalance(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")


    command = "update emp2 10"
    response = remote_server.UpdateLeave(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")

    command = "get emp2 balance"
    MyProcessName = "P1"


    response = remote_server.getLeaveBalance(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")


    command = "delete emp2 10"
    response = remote_server.DeleteLeave(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")

    command = "get emp2 balance"
    MyProcessName = "P1"


    response = remote_server.getLeaveBalance(command, MyProcessName)
    print (f" You are successfully completed and status : {response}")
"""