# Project 3 
# Develop a client-server application where the server manages employee leave details, and the
#  client can request leave information and updates using socket programming.
# Name: Jatin K rai
#DawID
"""
    The server maintains a record of each employee's leave details, which includes:

    Total entitled leaves: The total number of leaves the employee can take.
    Current leave balance: The number of leaves the employee has remaining.

    The server listens for requests from multiple clients, processes leave requests, and sends back appropriate responses.
"""
import threading


# Create a class
class clsProject3LeaveData():

    employee_leaves = ()
       #Constuctor
    def __init__(self):
        self.MyCurrentProcessName = "P"
        self.lock = threading.Lock()
        # Employee leave details
        self.employee_leaves = {
                "emp1": {"total": 30, "balance": 30},
                "emp2": {"total": 25, "balance": 25},
                "emp3": {"total": 15, "balance": 15},
                # Add more employees as needed
            }
    
    #return all employee leave bank.
    def getLeaveData(self):
        return self.employee_leaves
    



    